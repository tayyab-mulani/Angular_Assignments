
class Arithematic
{
    No1 : number;
    No2 : number;

    constructor(A : number, B : number)
    {
        this.No1 = A;
        this.No2 = B;
    }

    Addition() : number
    {
        return (this.No1 + this.No2);
    }

    Substraction() : number
    {
        return (this.No1 - this.No2);
    }

    Multiplication() : number
    {
        return (this.No1 * this.No2)
    }

    Division() : number
    {
        return (this.No1 / this.No2)
    }
}
var Obj = new Arithematic(11,10);

var Ret : number = 0;

Ret = Obj.Addition();
console.log("Addition of obj : "+Ret);   

Ret = Obj.Substraction();
console.log("Substraction of obj : "+Ret);   

Ret = Obj.Multiplication();
console.log("Multiplication of obj : "+Ret);

Ret = Obj.Division();
console.log("Division of obj : "+Ret);