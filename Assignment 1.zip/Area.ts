function Area(Radius : number) : void
{
    var PI : number = 3.14
    var iArea : number = 0

    iArea = PI * Radius * Radius

    console.log("Area of Circle is  = "+iArea)
}

var iRad : number = 5 

Area(iRad)